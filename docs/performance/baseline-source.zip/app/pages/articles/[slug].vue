<script setup lang="ts">
import type { PublicArticle } from "#shared/types/content";
definePageMeta({ layout: "public" });
const route = useRoute();
const { data, error } = await useFetch<{ data: PublicArticle }>(() => `/api/public/articles/${encodeURIComponent(String(route.params.slug))}`, { retry: 0 });
if (error.value || !data.value) throw createError({ statusCode: error.value?.statusCode === 404 ? 404 : 503, statusMessage: "Article unavailable", data: { entity: "article" }, fatal: true });
const article = data.value.data;
const updated = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", year: "numeric", timeZone: "Europe/Moscow" }).format(new Date(`${article.updatedAt}T12:00:00Z`)).replace(/ г\.$/, "");
usePageSeo(`${article.title} — WorkFlow`, article.description, `/articles/${article.slug}`, "article");
useSeoMeta({ articleModifiedTime: article.updatedAt });
</script>
<template>
  <article class="public-content public-article">
    <h1>{{ article.title }}</h1><p class="page-subtitle">{{ article.category }} · Обновлено {{ updated }}</p>
    <div class="panel article-body"><section v-for="section in article.sections" :key="section.title"><h2>{{ section.title }}</h2><p>{{ section.text }}</p></section><ArticleFeedback :slug="article.slug" /></div>
  </article>
</template>
