export default defineNuxtConfig({
  compatibilityDate: "2026-11-15",
  runtimeConfig: { public: { siteUrl: process.env.NUXT_PUBLIC_SITE_URL ?? "http://127.0.0.1:3005" } },
  devtools: { enabled: false },
  modules: ["@pinia/nuxt", "@nuxt/eslint"],
  css: [
    "@fontsource/montserrat/400.css",
    "@fontsource/montserrat/500.css",
    "@fontsource/montserrat/600.css",
    "@fontsource/montserrat/700.css",
    "@fontsource/nunito-sans/400.css",
    "~/assets/css/main.css",
    "~/assets/css/responsive.css",
    "~/assets/css/public.css",
  ],
  app: {
    head: {
      htmlAttrs: { lang: "ru" },
      title: "WorkFlow — управление заявками",
      meta: [
        {
          name: "description",
          content:
            "Единое рабочее пространство для заявок, команды и понятных процессов.",
        },
      ],
    },
  },
  typescript: { strict: true },
});
