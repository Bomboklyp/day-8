import withNuxt from "./.nuxt/eslint.config.mjs";

export default withNuxt({
  rules: { "no-empty": ["error", { allowEmptyCatch: true }] },
});
